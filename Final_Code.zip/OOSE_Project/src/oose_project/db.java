package oose_project;
import java.sql.*;
import javax.swing.*;
public class db 
{
Connection conn=null;
    public static Connection java_db()
    {
          try {
           String url = new String();
           String user = new String();
           String password = new String();
           url = "jdbc:mysql://localhost:3306/jobportal";
           user = "root";
           password = "";
           
           DriverManager.registerDriver(new com.mysql.jdbc.Driver());
           Connection conn= DriverManager.getConnection(url,user,password);
           //JOptionPane.showMessageDialog(null,"Connection Successfuly");
           return conn;
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, "Connection Failed" +e);
                     return null;
                }       
       
    }
}
   
