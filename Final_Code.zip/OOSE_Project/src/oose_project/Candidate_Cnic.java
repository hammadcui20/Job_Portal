/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package oose_project;

/**
 *
 * @author dell
 */
public class Candidate_Cnic {
    public static int cnic;
    
}
